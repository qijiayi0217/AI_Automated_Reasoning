Name: Jiayi Qi
NetID: jqi8
No collaborators
basic.py is for part 1
advanced.py is for part 2

To run my project's programs, just simply use command:
$  python3 filename.py

All the result is printed out after the question in your terminal.